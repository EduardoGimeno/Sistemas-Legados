package com.example.legados3.Service;

import com.example.legados3.Model.Game;
import com.example.legados3.OCR.OCR;
import com.example.legados3.Wrapper.DosWrapper;
import org.springframework.stereotype.Service;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class WebService {

    private final DosWrapper dosWrapper;
    private final OCR ocr;

    public WebService() throws AWTException {
        this.dosWrapper = new DosWrapper();
        this.ocr = new OCR();
    }

    public String countGames() {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // First we select option to search
        dosWrapper.pressKey('4');

        // Now we take a screenshot
        BufferedImage capture = dosWrapper.takeCapture();

        // After the screencapture we pass the image to the OCR process to obtain the text
        String result = ocr.readImage(capture, "spa");

        // Identify result
        List<String> list = Arrays.stream(result.split("\\r?\\n")).collect(Collectors.toList());

        // Exit
        dosWrapper.pressKey('\n');

        List<String> aux = Arrays.asList(list.get(1).split(" "));

        return "" + aux.get(1);
    }

    public List<Game> filterTitle(String title) {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // First we select option to search
        dosWrapper.pressKey('7');
        // We confirm we dont know the registry number
        dosWrapper.pressKey('N');
        dosWrapper.pressKey('\n');
        // Now we introduce the game title that has been passed
        for(int i = 0; i < title.length(); i++){
            char c = title.charAt(i);
            dosWrapper.pressKey(c);
        }
        // We press enter to search and wait
        dosWrapper.pressKey('\n');
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Now we take a screenshot
        BufferedImage capture = dosWrapper.takeCapture();

        // After the screencapture we pass the image to the OCR process to obtain the text
        String result = ocr.readImage(capture, "spa");

        if (result.contains("NO HAY NINGUN")) {
            dosWrapper.pressKey('\n');
            dosWrapper.pressKey('N');
            dosWrapper.pressKey('\n');
            return Collections.emptyList();
        }

        // Exit execution
        dosWrapper.pressKey('S');
        dosWrapper.pressKey('\n');
        dosWrapper.pressKey('N');
        dosWrapper.pressKey('\n');
        dosWrapper.pressKey('N');
        dosWrapper.pressKey('\n');

        // Identify result
        List<String> list =
                Arrays.stream(result.split("\\r?\\n")).filter(item -> {
                    if (Character.isDigit(item.charAt(0))) {
                        return Character.isDigit(item.charAt(item.length()-1));
                    }
                    return false;
                }).collect(Collectors.toList());

        return interpretGames(list);
    }

    public List<Game> filter(String tape) {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // First we select option to search
        dosWrapper.pressKey('6');
        // We confirm to list all
        dosWrapper.pressKey('\n');

        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        List<Game> games = new ArrayList<>();
        String fin = "";
        BufferedImage capture;

        while (!fin.contains("MENU")) {
            // Now we take a screenshot
            capture = dosWrapper.takeCapture();

            // Control the end of search
            fin = ocr.readImage(capture, "spa");

            // After the screencapture we pass6
            // the image to the OCR process to obtain the text
            String result = ocr.readImage(capture, "spa2");

            capture.flush();

            // Identify result
            List<String> list =
                    Arrays.stream(result.split("\\r?\\n")).filter(item -> {
                        if (!item.isEmpty() && Character.isDigit(item.charAt(0))) {
                            return Character.isDigit(item.charAt(item.length()-1));
                        }
                        return false;
                    }).collect(Collectors.toList());

            games.addAll(interpreteGames(list));

            // Press SPACE to see next page
            dosWrapper.pressKey(' ');

            try {
                Thread.sleep(50);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        if (!tape.equals("")) {
            games = games.stream().filter(game -> game.getTape().contains(tape)).collect(Collectors.toList());
        }

        return games;
    }

    private List<Game> interpretGames(List<String> list) {
        List<Game> games = new ArrayList<>();
        for (String s : list) {
            List<String> words = Arrays.asList(s.split("\\s+"));
            games.add(new Game("", words.get(2), words.get(3), words.get(5).replace("CINTA:", ""), words.get(0)));
        }
        return games;
    }

    private List<Game> interpreteGames(List<String> list) {
        List<Game> games = new ArrayList<>();
        for (String s : list) {
            List<String> words = Arrays.asList(s.split("\\s+"));
            if (words.size() >= 5) {
                String id = words.get(0);
                StringBuilder name = new StringBuilder();
                for (int i = 1; i < words.size() - 3; i++) {
                    name.append(words.get(i));
                }
                String type = words.get(words.size()-3);
                String tape = words.get(words.size()-2);
                String registry = words.get(words.size()-1);
                games.add(new Game(id, name.toString(), type, tape, registry));
            }
        }
        return games;
    }
}

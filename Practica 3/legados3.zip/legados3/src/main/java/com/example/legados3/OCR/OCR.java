package com.example.legados3.OCR;


import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract1;
import net.sourceforge.tess4j.TesseractException;

import java.awt.image.BufferedImage;
import java.io.File;

public class OCR {

    private final ITesseract tesseract;

    public OCR() {
        this.tesseract = new Tesseract1();
        tesseract.setDatapath("src/main/resources/tessdata");
    }

    public String readImage(BufferedImage capture, String locale) {
        tesseract.setLanguage(locale);
        String result = "";
        try {
            result = tesseract.doOCR(capture);
        } catch (TesseractException e) {
            e.printStackTrace();
        }
        return  result;
    }
}

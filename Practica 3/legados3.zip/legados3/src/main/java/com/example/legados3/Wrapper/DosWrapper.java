package com.example.legados3.Wrapper;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

public class DosWrapper {

    private final Robot robot;

    public DosWrapper() throws AWTException {
        robot = new Robot();
        robot.setAutoDelay(20);
        robot.waitForIdle();
    }

    public void pressKey(char character) {
        try {
            boolean upperCase = Character.isUpperCase( character );
            Thread.sleep(250);
            if (upperCase) robot.keyPress( KeyEvent.VK_SHIFT );
            robot.keyPress(KeyEvent.getExtendedKeyCodeForChar(character));
            robot.keyRelease(KeyEvent.getExtendedKeyCodeForChar(character));
            if (upperCase) robot.keyRelease( KeyEvent.VK_SHIFT );
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    public BufferedImage takeCapture() {
        return robot.createScreenCapture(new Rectangle(0, 40, 650, 400));
    }

}

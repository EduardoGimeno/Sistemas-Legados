package com.example.legados3.Controller;

import com.example.legados3.Service.WebService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class WebController {

    private final WebService webService;

    public WebController(WebService webService) {
        this.webService = webService;
    }

    @GetMapping(path = "/")
    public String getHome(Model model) {
        model.addAttribute("numGames", webService.countGames());
        return "index";
    }

    @GetMapping(path = "/listTitle")
    public String getListTitle(Model model, @RequestParam(name = "title") String title) {
        model.addAttribute("games", webService.filterTitle(title));
        return "listTitle";
    }

    @GetMapping(path = "/list")
    public String getList(Model model, @RequestParam(name = "tape") String tape) {
        model.addAttribute("games", webService.filter(tape));
        return "list";
    }

}

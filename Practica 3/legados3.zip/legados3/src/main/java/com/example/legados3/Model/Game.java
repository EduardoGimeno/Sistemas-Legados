package com.example.legados3.Model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Game {

    private String id;

    private String name;

    private String type;

    private String tape;

    private String registry;
}
